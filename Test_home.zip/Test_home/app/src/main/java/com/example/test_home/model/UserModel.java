package com.example.test_home.model;

public class UserModel
{
    public String userName;
}
